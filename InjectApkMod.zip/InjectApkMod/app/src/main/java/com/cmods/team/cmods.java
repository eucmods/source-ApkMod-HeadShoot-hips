package com.cmods.team;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface.OnClickListener;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
import android.widget.EditText;
import android.content.res.AssetManager;
import java.io.InputStream;
import java.io.OutputStream;
import android.widget.Toast;
import java.io.FileOutputStream;
import java.io.IOException;

public class cmods {
	public static void Start(Context coringa) {
		inject(coringa);
	}

	public static void inject(Context coringa) {
		AssetManager as = coringa.getAssets();
        InputStream inx = null;
        OutputStream  outx = null;
        String flname = "cmods";
        try{
            Toast.makeText(coringa, "Inject Sucess.", Toast.LENGTH_LONG).show();
            inx = as.open(flname);
            outx = new FileOutputStream("/storage/emulated/0/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/avatar/" + "assetindexer.PSrlap~2BbZcfMCxyw~2Bt7dClukzYs~3D");
            CMODsS(inx,outx);
            inx.close();
            inx = null;
            outx.flush();
            outx.close();
            outx = null;
        }catch(IOException ee){
            Toast.makeText(coringa, "Nao foi Possivel injetar por: " + ee, Toast.LENGTH_LONG).show();
        }
    }
    private static void CMODsS(InputStream inx, OutputStream outx) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while((read = inx.read(buffer)) != -1) {
            outx.write(buffer, 0, read);
        }
	}
}

